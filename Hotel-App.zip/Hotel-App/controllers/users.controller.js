const { default: mongoose } = require('mongoose')
const usersModels = require('../models/users.models')
const Users = require('../models/users.models')
const authMiddleware = require('../helpers/authMiddleware')
const { body, validationResult } = require('express-validator')
const ValidateUser = require('../validation/users.validation')
const jwt = require('jsonwebtoken')
const bcrypt = require('bcrypt')
require('dotenv').config()

const AddUser = async (req, res) => {
  const { errors, isValid } = ValidateUser(req.body)
  try {
    if (!isValid) {
      res.status(400).json(errors)
    } else {
      await Users.findOne({ Email: req.body.Email }).then(async exist => {
        if (exist) {
          errors.Email = 'Users Exist'
          res.status(400).json(errors)
        } else {
          let newUser = new Users(req.body)
          bcrypt.genSalt(10, (err, salt) => {
            if (err) {
              throw err
            }

            bcrypt.hash(req.body.Password, salt, (err2, hashedPwd) => {
              if (err2) {
                throw err2
              }
              newUser.Password = hashedPwd
              newUser.save()
            })
          })
          // await Users.create(req.body)
          res.status(201).json({ message: 'Users added with success!' })
        }
      })
    }
  } catch (error) {
    console.log(error.message)
  }
}

const FindAllUsers = async (req, res) => {
  try {
    const data = await Users.find()
    res.status(200).json(data)
  } catch (error) {
    console.log(error.message)
  }
}
const FindSingleUser = async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      res.status(400).json({ message: 'Invalid Data' })
    }
    const data = await Users.findOne({ _id: req.params.id })
    if (data) {
      res.status(200).json(data)
    } else {
      res.status(404).json({ message: 'Users Not Found' })
    }
  } catch (error) {
    console.log(error.message)
  }
}
const UpdateUser = async (req, res) => {
  if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
    res.status(400).json({ message: 'Invalid Data' })
  }
  const { errors, isValid } = ValidateUser(req.body)
  try {
    if (!isValid) {
      res.status(400).json(errors)
    } else {
      /*
    1)getting user with id (1) */

      const currentUser = await Users.findOne({ _id: req.params.id })
      console.log(currentUser)
      console.log('hello')

      /*2)comparing the user found Email to request Email*/
      if (currentUser) {
        if (currentUser.Email === req.body.Email) {
          const data = await Users.findOneAndUpdate(
            { _id: req.params.id },
            req.body,
            { new: true }
          )
          res.status(201).json(data)
        } else {
          /*
    3)if the current Email not equal to request Email then chcking if an Email exist,
    if it exist throw an error, else etape4.
    4)if the current Email is equal to the request Email then update the other fields of the user.
    */
          const data = await Users.find({
            _id: { $ne /* not equal */: currentUser._id },
          })
          console.log('data', data)
          const arrayWithoutEmail = data.filter(
            user => user.Email === req.body.Email
          )
          console.log('filtredData', arrayWithoutEmail)
          if (arrayWithoutEmail.length === 0) {
            const updatedUser = await Users.findOneAndUpdate(
              { _id: req.params.id },
              req.body,
              { new: true }
            )
            res.status(201).json(updatedUser)
          } else {
            errors.Email = 'Users Exist'
            res.status(400).json(errors)
          }
        }
      }
    }
  } catch (error) {
    console.log(error.message)
  }
}
const DeleteUser = async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      res.status(400).json({ message: 'Invalid Data' })
    }
    const user = await Users.findOne({ _id: req.params.id })
    if (user) {
      const data = await Users.deleteOne(
        { _id: req.params.id },
        (error, data) => {
          if (error) {
            res.status(400).json({ message: 'error' })
          }
          if (data) {
            res.status(201).json({ message: 'Users deleted with success' })
          }
        }
      )
    } else {
      res.status(404).json({ message: 'Users Not Found' })
    }
  } catch (error) {
    console.log(error.message)
  }
}

const RegisterUser =
  ([
    body('Firstname', 'Firstname must contain only alphabetic').isAlpha(),
    body('Lastname', 'Lasttname must contain only alphabetic').isAlpha(),
    body('Email', 'Please enter a valid Email').isEmail(),
    body('Phone', 'phone must contain only number').isNumeric(),
    body('Password', 'Mininmum length allowed is 5 characters').isLength({
      min: 5,
    }),
  ],
  (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() })
    }

    Users.find({ Email: req.body.Email }).then(users => {
      if (users.length) {
        return res
          .status(400)
          .send({ errors: [{ msg: 'User already exists!' }] })
      }

      let newUser = new Users(req.body)
      bcrypt.genSalt(10, (err, salt) => {
        if (err) {
          throw err
        }

        bcrypt.hash(req.body.Password, salt, (err2, hashedPwd) => {
          if (err2) {
            throw err2
          }
          newUser.Password = hashedPwd
          newUser.save()

          let payload = {
            userId: newUser._id,
          }
          jwt.sign(payload, process.env.SECRET_KEY, (err, token) => {
            if (err) {
              throw err
            }
            res.send({ token })
          })
        })
      })
    })

    // res.send(req.body);
  })

/*Login */

const LoginUser =
  ([
    body('Email', 'Please enter a valid Email').isEmail(),
    body('Password', 'Please write your password ').notEmpty(),
  ],
  (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() })
    }
    Users.findOne({ Email: req.body.Email }).then(user => {
      if (!user) {
        return res
          .status(404)
          .json({ errors: [{ msg: 'Please register before' }] })
      }

      bcrypt.compare(req.body.Password, user.Password, (err, isMatch) => {
        if (err) {
          throw err
        } else if (!isMatch) {
          return res.json({ errors: [{ msg: 'Wrong Password!' }] })
        } else {
          let payload = {
            userId: user._id,
          }
          jwt.sign(payload, process.env.SECRET_KEY, (err, token) => {
            if (err) {
              throw err
            }
            res.send({ token })
          })
        }
      })
    })
  })

module.exports = {
  AddUser,
  FindAllUsers,
  FindSingleUser,
  UpdateUser,
  DeleteUser,
  RegisterUser,
  LoginUser,
}
