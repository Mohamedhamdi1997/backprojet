const express = require('express')
const {
  AddUser,
  FindAllUsers,
  FindSingleUser,
  UpdateUser,
  DeleteUser,
  RegisterUser,
  LoginUser,
} = require('../controllers/users.controller')
const router = express.Router()

/*router.get('/api', (req, res) => {
  res.send('work')
})*/

/* add user */
router.post('/users', AddUser)
/* find all users */
router.get('/users', FindAllUsers)
/* find single user */
router.get('/users/:id', FindSingleUser)
/* update user */
router.put('/users/:id', UpdateUser)
/* delete user */
router.delete('/users/:id', DeleteUser)
/* register user */
router.post('/register-user', RegisterUser)
/*login user */
router.post('/login-user', LoginUser)

module.exports = router
