const mongoose = require('mongoose')
const Schema = mongoose.Schema

const UserSchema = new Schema(
  {
    Email: String,
    FirstName: String,
    LastName: String,
    Phone: Number,
    Password: String,
  },
  { timestamps: true } // yetsejel wa9tech 3melt l action fel base de donnnée
)

module.exports = mongoose.model('users', UserSchema)
